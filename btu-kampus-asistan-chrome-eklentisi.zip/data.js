const CLASSROOMS_DATA = {
  "E/Z27 Laboratuvar M.Sinan Yer. (E Blok)": [
    {
      "day": "Cuma",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E/448 M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / Z05": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "E/347 M.Sinan Yer. (E Blok)": [
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/Z25 Laboratuvar M.Sinan Yer. (E Blok)": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/Z34 Laboratuvar M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "Uzaktan Eğitim": [
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/304 M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "Ö.Ü. Ofis": [
    {
      "day": "Cumartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "Dr.Öğr.Üyesi Önder CANBULAT, A-266": [
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E/447 M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 151": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 153": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 373": [
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 369": [
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 363": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 371": [
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / E Blok / 204": [
    {
      "day": "Pazartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS / E Blok / 139": [
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "MS / E Blok / Z34": [
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "MS / G Blok / Z05": [
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    }
  ],
  "MS / G Blok / 252": [
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "MS / E Blok / 305": [
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "MS / G Blok / Z53": [
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "MS / E Blok /446": [
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "MS/ E Blok /204": [
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / Z53": [
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / E Blok /139": [
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS / E Blok /204": [
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    }
  ],
  "Koray ALTUN MS / E Blok /204": [
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 252": [
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS/ G Blok /252": [
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "Zekeriya DOĞRUYOL, E/306 Bilgisayar E Blok Lab. M.Sinan Yer.": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "Mehmet BÜYÜKYILDIZ, MS / G blok / 352": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "ŞAHİN, MS / G blok / 252": [
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "Fizik I Laboratuvarı L, Fizik A, Mehmet BÜYÜKYILDIZ, E/Z34 E Blok Laboratuvar M.Sinan Yer.": [
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "Ayşegül Çiğdem ADIGÜZEL, E/405 E Blok Konf.Sal. M.Sinan Yer.": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "T, Fizik A, Hüseyin DAĞ, E/205 M.Sinan E Blok Yer.": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "Fizik A, Murat TÜREMİŞ, E/205 M.Sinan E Blok Yer.": [
    {
      "day": "Çarşamba",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E Blok DOĞRUYOL, E/205 M.Sinan Yer.": [
    {
      "day": "Perşembe",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "Fizik E, Nihal ÖZDOĞAN, MS / G blok /": [
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "DOĞRUYOL, MS / G blok / 352": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "Laboratuvarı L, Fizik A, Murat TÜREMİŞ, E Blok E/Z33 Laboratuvar M.Sinan Yer.": [
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E Blok Laboratuvar M.Sinan Yer.": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "Ayten KAYA, MS / G blok / 355": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "T, Fizik A, Songül AKBULUT ÖZEN, MS / G blok / 355": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "T, Fizik A, Barış Tamer TONGUÇ, E/205 E Blok M.Sinan Yer.": [
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "BÜYÜKYILDIZ, E/205 M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "Mustafa Şükrü KURT, E/205 M.Sinan Yer. E Blok": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E Blok KARAAĞAÇ, E/205 M.Sinan Yer.": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "Şube G1, E-Z34": [
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    }
  ],
  "/ A - 2 6 5": [
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    }
  ],
  "E/204 Bilgisayar Lab. M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "E/124 M.Sinan Yer. (E Blok)": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "E/Z32 M.Sinan Yer. (E Blok)": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E/404 M.Sinan Yer. (E Blok)": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/346 M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/305 Bilgisayar Lab. M.Sinan Yer. (E Blok)": [
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/125 M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "E/125 M.Sinan Yer. (E Blok) Ders, 3. ve 4. sınıf öğrencileri için ortak seçmeli ders olup her iki sınıf öğrencisi tarafından seçilebilir.": [
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "E/404 M.Sinan Yer. (E Blok) Ders, 3. ve 4. sınıf öğrencileri için ortak seçmeli ders olup her iki sınıf öğrencisi tarafından seçilebilir.": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "E/125 M.Sinan Yer. (E Blok) (2016 Müfredatı)": [
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "E/124 M.Sinan Yer. (E Blok) Ders, 3. ve 4. sınıf öğrencileri için ortak seçmeli ders olup her iki sınıf öğrencisi tarafından seçilebilir.": [
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/131 Laboratuvar M.Sinan Yer. (E Blok)": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / G Blok / 253": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    }
  ],
  "MS / E Blok / 405": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    }
  ],
  "MS / G Blok / 251": [
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "MS / E Blok / 104": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    }
  ],
  "MS / G Blok / 253 SEZGİN": [
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "YB / A Blok / 436-A": [
    {
      "day": "Cuma",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    }
  ],
  "YB / PL1 LAB / Z01": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "MS / E Blok / 304": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "MS / E Blok / 203": [
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "MS / G Blok / 154": [
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    }
  ],
  "UZEM": [
    {
      "day": "Cuma",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/Z08": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/BZ08": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/B205": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/205": [
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok//B205": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/B209": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "E/405 Konf.Sal. M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "E/331 M.Sinan Yer. (E Blok)": [
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/Z23 Laboratuvar M.Sinan Yer. (E Blok)": [
    {
      "day": "Cuma",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 351": [
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 354": [
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E/240 M.Sinan Yer. (E Blok)": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/242 M.Sinan Yer. (E Blok)": [
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 152": [
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 254": [
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "TÜREMİŞ E-Z32 1. SINIF": [
    {
      "day": "Perşembe",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "ERKEN G-Z54 1. SINIF": [
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "G-454": [
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "DEMİRCİ G-Z54 Muhammet CAN E-104 1. SINIF": [
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "TÜREMİŞ E-104 1. SINIF": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "G-154 2. SINIF": [
    {
      "day": "Pazartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    }
  ],
  "Hakan ÜLKER G-454 Onur KADEM G-Z54 2. SINIF": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "AYDINBAKAR G-454 2. SINIF": [
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "ERTAŞ G-154 2. SINIF": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "Online 2. SINIF": [
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "ÜLKER G-178 3. SINIF": [
    {
      "day": "Cuma",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E-104 3. SINIF Engineering Materials": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "PARLAKYİĞİT G-Z54 3. SINIF": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "ERTAŞ E-104 3. SINIF": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "TURAN G-Z54 Ali Hüsnü BADEMLİOĞLU E-104 3. SINIF": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E-104 3. SINIF Electrochemical Energy Storage: Battery Technologies": [
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "G-Z54 3. SINIF Modelling of Dynamic Systems": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "Furkan SÖKMEN G-Z54 Levent AYDINBAKAR G-154 3. SINIF": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "BAYRAK G-154 3. SINIF": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "G-Z05 3. SINIF": [
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/348 M.Sinan Yer. (E Blok)": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "E/103 M.Sinan Yer. (E Blok)": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "E/241 M.Sinan Yer. (E Blok)": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "A/265 M.Sinan Yer. (A Blok)": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E/446 M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    }
  ],
  "E-305": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "G-Z51": [
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "Fizik I Lab E-Z34": [
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "Z05)": [
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E-138": [
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "Z51)": [
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "G-Z52": [
    {
      "day": "Pazartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "G-374": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "Online": [
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "G-368": [
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "Enstrümantasyon Lab (G": [
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "Ofis": [
    {
      "day": "Cumartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    }
  ],
  "G-362": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "G-370": [
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "G-368 Tasarımı Lab": [
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "G-370 Conversion Lab": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "Instrumentation Lab G-362": [
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "Neriman SİNAN TATL E/Z27 Laboratuvar M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "1, E/346 M.Sinan Yer. (E Blok) Prof. Gökçe BORAND, E/140 M.Sinan Yer. (E Blok) Dr. Cem KAHRUMAN ile birlikte yürütülecektir.": [
    {
      "day": "Pazartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E/346 M.Sinan Yer. (E Blok) Prof. Dr. Cem KAHRUMAN ile birlikte yürütülecektir.": [
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E/346 M.Sinan Yer. (E Blok) Doç. Dr. Yakup YÜREKTÜRK ile birlikte yürütülecektir.": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "E/140 M.Sinan sonrası) Şube 1, Muhammet ULUDAĞ, Yer. (E Blok) E/346 M.Sinan Yer. (E Blok)": [
    {
      "day": "Perşembe",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E/140 M.Sinan Yer. (E Blok)": [
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "E/436 Laboratuvar M.Sinan Yer. (E Blok)": [
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E/Z32 M.Sinan Yer. (E": [
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    }
  ],
  "E/432 Laboratuvar M.Sinan Yer. (E Blok)": [
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "MS G blok / 355": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "Ö.Ü. Ofis sonrası) Şube 1, Serhat KAAN, E/346": [
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 17,
      "start": "17:00",
      "end": "17:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 18,
      "start": "18:00",
      "end": "18:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 19,
      "start": "19:00",
      "end": "19:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 17,
      "start": "17:00",
      "end": "17:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 18,
      "start": "18:00",
      "end": "18:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 19,
      "start": "19:00",
      "end": "19:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 17,
      "start": "17:00",
      "end": "17:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 18,
      "start": "18:00",
      "end": "18:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 19,
      "start": "19:00",
      "end": "19:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 17,
      "start": "17:00",
      "end": "17:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 18,
      "start": "18:00",
      "end": "18:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 19,
      "start": "19:00",
      "end": "19:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 17,
      "start": "17:00",
      "end": "17:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 18,
      "start": "18:00",
      "end": "18:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 19,
      "start": "19:00",
      "end": "19:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 17,
      "start": "17:00",
      "end": "17:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 18,
      "start": "18:00",
      "end": "18:45",
      "status": "DOLU"
    },
    {
      "day": "Cumartesi",
      "hour": 19,
      "start": "19:00",
      "end": "19:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/109": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "TANRIÖVER YB/B Blok/207": [
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "ASENKRON/ ONLINE UZEM": [
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/207": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "TANRIÖVER YB/B Blok/107": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/109": [
    {
      "day": "Cuma",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/!09": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "YB/A Blok/Z36D": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/Z09": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "TANRIÖVER YB/B Blok/109": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "YB/A Blok/236D": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "MS E Blok 405": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS A307": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS A 307": [
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS A 308": [
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "MS A210": [
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS A 210": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS A308": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS A B17": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "BAŞBOĞA MS A 210": [
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "KOYUNCU E BLOK 405": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    }
  ],
  "Öğretim Üyesi Ofisi": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS-A 365": [
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "ERTAŞ Öğretim Üyesi Ofisi": [
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E BLOK 405": [
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "YAVUZ": [
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "SARIKAYA MS-A 301": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "ÖZEMRE": [
    {
      "day": "Cuma",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "B17": [
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "Ayşe Nur REÇBEROĞULLARI": [
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "İDE": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "SÖNMEZ MS-A- 302": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "TAŞ MS-A 301": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "SARIYILDIZ Öğretim Üyesi Ofisi": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "GÜNDOĞDU MS-A 301": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    }
  ],
  "MS-A 208": [
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "MS-A 301": [
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS-A 301/B17": [
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    }
  ],
  "MS-A 302": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "SARIYILDIZ MS-A 302": [
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "ARICAK MS-A 301": [
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "DİLER": [
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "SÖNMEZ B17": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    }
  ],
  "ERKAN MS-A 208": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    }
  ],
  "KADIOĞULLARI MS-A 365": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS- A 365": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 451": [
    {
      "day": "Pazartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / Z04": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 453": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 452": [
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "Mimar Sinan Kampüsü A-364": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "Mehmet Kasım KOYUNCU) (Mimar Sinan Kampüsü A-364)": [
    {
      "day": "Perşembe",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "Onur AKSOY) (Mimar Sinan Kampüsü A- 363)": [
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  ". Yalçın YILDIRIM, Mimar Sinan Kampüsü A-363": [
    {
      "day": "Perşembe",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "Nazlı Deniz ERSÖZ) (Mimar Sinan Kampüsü A-363)": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "Mimar Sinan Kampüsü A-363": [
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "(Mimar Sinan Kampüsü A-363)": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "Mimar Sinan A-357": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "Mimar Sinan Kampüsü A-357": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "Sinan Kampüsü A-357)": [
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "(Mimar Sinan Kampüsü A-357)": [
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "Kampüsü A-357)": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/225 M.Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/431 M.Sinan Yer. (E Blok)": [
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/ B105": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "ALTIPARMAK YB/B Blok /B105": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/B103": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "Uzem": [
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "Uzem SÜZGÜN IŞIK": [
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/ B103": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/B107": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/ B107": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "YB/B Blok/B105": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "AHMEDİ YB/B Blok/B107": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "ŞENSES AKSU YB/B Blok/B103": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "YB/B B103": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ B204": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ Z03": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazar",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ B106": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ B104": [
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ Z09": [
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ B208": [
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ B203": [
    {
      "day": "Pazar",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazar",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "ÖZDEMİR YB/ B Blok/ B208": [
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "ALTUN YB/ B Blok/ B206": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ 208": [
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazar",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazar",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazar",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ B206": [
    {
      "day": "Pazartesi",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ 206": [
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazar",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazar",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ 159": [
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ Z-03": [
    {
      "day": "Pazar",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    }
  ],
  "YB/ B Blok/ 203": [
    {
      "day": "Pazar",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    }
  ],
  "E/205 M.Sinan Yer. (E Blok)": [
    {
      "day": "Cuma",
      "hour": 8,
      "start": "08:00",
      "end": "08:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "E/306 Bilgisayar Lab. M.Sinan Yer. (E Blok)": [
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/404 M. Sinan Yer. (E Blok)": [
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "E/306 Bilgisayar Lab. M. Sinan Yer. (E Blok)": [
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "E/406 M.Sinan Yer. (E Blok)": [
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 352": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / Z03": [
    {
      "day": "Pazartesi",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 353": [
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Çarşamba",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 16,
      "start": "16:00",
      "end": "16:45",
      "status": "DOLU"
    }
  ],
  "MS / G blok / 355": [
    {
      "day": "Pazartesi",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Salı",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    },
    {
      "day": "Pazartesi",
      "hour": 15,
      "start": "15:00",
      "end": "15:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 9,
      "start": "09:00",
      "end": "09:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Cuma",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 13,
      "start": "13:00",
      "end": "13:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 14,
      "start": "14:00",
      "end": "14:45",
      "status": "DOLU"
    }
  ],
  "E/127 Laboratuvar M.Sinan Yer. (E Blok)": [
    {
      "day": "Perşembe",
      "hour": 10,
      "start": "10:00",
      "end": "10:45",
      "status": "DOLU"
    },
    {
      "day": "Perşembe",
      "hour": 11,
      "start": "11:00",
      "end": "11:45",
      "status": "DOLU"
    }
  ]
};
